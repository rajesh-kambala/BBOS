2023-08
While upgrading CRM to the new version, we had a bunch of display-related defects we had to resolve.  Here are 5 files that were updated.  This zip file has the delta changes only, not the full file.

D:\Applications\CRM\WWWRoot\prco_compat.css
D:\Applications\CRM\WWWRoot\js\calendar\responsiveCalendarUtils.js
D:\Applications\CRM\WWWRoot\Themes\color1.css
D:\Applications\CRM\WWWRoot\Themes\ergonomic.css
D:\Applications\CRM\WWWRoot\Themes\Fonts\colourPalatte.css

Additionally, we had some data corrections that were needed (CRM Upgrade DataCorrections.sql in this zip file).