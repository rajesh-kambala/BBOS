// PNCOMClientTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PNCOMClientTest.h"
#include "PNCOMClientTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPNCOMClientTestDlg dialog

CPNCOMClientTestDlg::CPNCOMClientTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPNCOMClientTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPNCOMClientTestDlg)
	m_Amount = 1.23f;
	m_CCExpDate = _T("1299");
	m_CCNum = _T("5105105105105100");
	m_HostAddress = _T("test-payflow.verisign.com");
	m_TranTimeout = 30;
	m_HostPort = 443;
	m_ParmList = _T("USER=user&VENDOR=vendor&PARTNER=partner&PWD=password&TRXTYPE=S&TENDER=C&ACCT=5105105105105100&EXPDATE=1205&AMT=1.23&ZIP=12345");
	m_ProxyAddress = _T("");
	m_ProxyLogon = _T("");
	m_ProxyPassword = _T("");
	m_ProxyPort = 0;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    CoInitialize(NULL);
	pnControl = NULL;
	m_nParmLen = m_ParmList.GetLength();
}

CPNCOMClientTestDlg::~CPNCOMClientTestDlg()
{
	if (pnControl) {
		//pnControl->pfproCleanup();
		pnControl->ReleaseDispatch();
		delete pnControl;
		pnControl = NULL;
	}
}


void CPNCOMClientTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPNCOMClientTestDlg)
	DDX_Control(pDX, IDC_RESULTS_LIST, m_ResultsList);
	DDX_Text(pDX, IDC_HOST_ADDRESS, m_HostAddress);
	DDX_Text(pDX, IDC_TRAN_TIMEOUT, m_TranTimeout);
	DDX_Text(pDX, IDC_HOST_PORT, m_HostPort);
	DDX_Text(pDX, IDC_PARM_LIST, m_ParmList);
	DDX_Text(pDX, IDC_PROXY_ADDRESS, m_ProxyAddress);
	DDX_Text(pDX, IDC_PROXY_LOGON, m_ProxyLogon);
	DDX_Text(pDX, IDC_PROXY_PASSWORD, m_ProxyPassword);
	DDX_Text(pDX, IDC_PROXY_PORT, m_ProxyPort);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPNCOMClientTestDlg, CDialog)
	//{{AFX_MSG_MAP(CPNCOMClientTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPNCOMClientTestDlg message handlers

BOOL CPNCOMClientTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	pnControl = new IPFProCOM;

	if (!pnControl) {
		MessageBox("Error allocating the VeriSign Control");
		return FALSE;
	}

	// you will need to call "CoInitialize(NULL);"
	// before you can use CreateDispatch. 
	// I call it in the constructor.
	// create VeriSign Com Client Object
	COleException pError;
	if (!pnControl->CreateDispatch("PFProCOMControl.PFProCOMControl.1",&pError)) {
		MessageBox("Error creating the Signio Control");
		return FALSE;
	}

	
	return TRUE;  
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPNCOMClientTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CPNCOMClientTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPNCOMClientTestDlg::OnOK() 
{

	CString csResponse;

	GetDlgItem(IDOK)->EnableWindow(FALSE);
	UpdateData(TRUE);

	long err = GetLastError();
	
	long ptrCtx = pnControl->CreateContext(m_HostAddress,(long)m_HostPort,
												(long)m_TranTimeout,m_ProxyAddress,
												m_ProxyPort,m_ProxyLogon,m_ProxyPassword);

	csResponse = pnControl->SubmitTransaction(ptrCtx,m_ParmList,m_ParmList.GetLength());	

	pnControl->DestroyContext(ptrCtx);
    


	PrintResponse(csResponse);

	GetDlgItem(IDOK)->EnableWindow(TRUE);
	UpdateData(FALSE);
}

// This function will print all the name/value pairs returned
void CPNCOMClientTestDlg::PrintResponse(CString &respStr)
{
    int  i;
    int  done = 0;
    char respBuf[256];
    char *ptr;
	const char *resp = respStr;

    // print the results
    while (!done) {
        i = 0;

        // parse out the individual name/value string
        while (resp && *resp && (*resp != '&')) {
            respBuf[i++]=*resp;
            resp++;
        }
        respBuf[i] = 0;

        // split the name from the value
        ptr = respBuf;
        while (ptr && *ptr && (*ptr != '='))
            ptr++;

        // finalize the split
        if (ptr && *ptr)
            *ptr = 0;
        else
            // error!
            return;

        // ptr will now equal the value portion
            ptr++;

        // print the name and the value
		CString tempBuf;
		tempBuf = respBuf;
		tempBuf += "=";
		tempBuf+=  ptr;
        //sprintf(tempBuf,"%s = %s",respBuf,ptr);
		m_ResultsList.AddString(tempBuf);

		// check the AVS format
		if (!stricmp(respBuf,"AVSADDR") ||
			!stricmp(respBuf,"AVSZIP")) {

			switch (*ptr) {
				case 'Y':  // good
					tempBuf = "Passed ";
					tempBuf += respBuf;
					break;

				case 'N': // bad
					tempBuf = "Failed ";
					tempBuf += respBuf;
					break;

				default: // other
					tempBuf = respBuf;
					tempBuf += " not processed";
					break;
			}

			m_ResultsList.AddString(tempBuf);
		}

        // skip the '&'
        if (resp && *resp) 
			resp++;
		else
			done = true;
    }
	m_ResultsList.AddString(" ");
}
