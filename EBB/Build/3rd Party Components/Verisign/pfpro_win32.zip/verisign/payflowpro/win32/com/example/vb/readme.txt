PAYFLOW PRO VB COM CLIENT EXAMPLE
---------------------------------
This directory contains the Visual Basic example for the Payflow Pro COM client.


REQUIREMENTS
------------
* Microsoft Windows 95/98/NT 4.0
* Microsoft Visual Basic 6.0


CONTENTS
--------
PNComClientTest.frm:    Visual Basic files for example
PNComClientTest.frx:    Visual Basic files for example
readme.txt:             This file
VBPNComClientTest.vbp:  Visual Basic files for example


HOW TO USE
----------
* Copy pfpro.dll to winnt\system32 directory.
* Run PFProCOMSetup.exe to install and register the Payflow Pro client plugin.
* Open the VBPNComClientTest.vbp file in Microsoft Visual Basic.
* Run the project.
* Enter the requested information using the params.txt file in the root 
  installation directory as a guide.
* Push the Send button
* You should receive a response similar to this:

    RESULT=0&PNREF=VXYZ00912465&ERRCODE=00&AUTHCODE=09TEST&AVSADDR=Y&AVSZIP=N&


NOTE
----
* You must set the SYSTEM environment variable PFPRO_CERT_PATH to point to the 
    directory that contains the file f73e89fd.0 in the certs subdirectory and
    reboot the machine.


CONTACT
-------
VeriSign, Inc. 
http://www.verisign.com
See contact.txt for additional contact information
