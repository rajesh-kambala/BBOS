PAYFLOW PRO TRANSACTION CLIENT V3.00
------------------------------------
This directory contains the Payflow Pro client pfpro Library and examples.

In addition to this readme file, full product documentation is
available. Download the "Payflow Pro Developer's Guide" from the
"Downloads" page of the VeriSign Manager website:
https://manager.verisign.com

REQUIREMENTS
------------
None


CONTENTS
--------
pfpro.dll:      Dynamic library to use in your own programs
pfpro.lib:      Dynamic library to link in your own programs
pfpro.h:        Header file to use in your own programs
readme.txt:     This file
example\c:      An example using Visual Studio


INSTALLATION
------------
* Copy pfpro.dll to a directory in the path, ie. c:\winnt\system32.


NOTE
----
Our Library client has three six points:

    pfproInit()                 - Initializes the client
    pfproCleanup()              - Frees up client resources
    pfproCreateContext()        - Creates a context to be used for sending transactions
    pfproDestroyContext()       - Frees up context resources
    pfproSubmitTransaction()    - Sends a transaction to the payment server
    pfproCompleteTransaction()  - Frees up transaction resources

pfproInit() and pfproCleanup() must be called once per process.  pfproInit()
must be called once at the start of the process, and pfproCleanup() must be called
once at the end of the process.

Between the calls to pfproInit() and pfproCleanup(), any number of contexts may be
created and any number of transactions may be sent.

A context must be created by calling pfproCreateContext() prior to sending any
transactions.  This context must be cleaned up by calling pfproDestroyContext().
Please refer to the included example for the proper usage.

In a multi-threaded environment, the calls to pfproInit() and pfproCleanup() must be
made from the main thread, and all threads must be created and complete
between the calls to pfproInit()/pfproCleanup().  Transactions may be submitted
any number of times from each of the created threads and the main thread,
however all threads must complete prior to the call to pfproCleanup() in the main
thread.

Please reference the enclosed Microsoft Visual Studio example in the 
example\c directory.

You must set the environment variable PFPRO_CERT_PATH to point to the directory that 
contains the file f73e89fd.0 in the certs subdirectory


CONTACT
-------
Verisign, Inc. 
http://www.verisign.com
See contact.txt for additional contact information




