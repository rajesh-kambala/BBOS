//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PNCOMClientTest.rc
//
#define IDD_PNCOMCLIENTTEST_DIALOG      102
#define IDD_CLIENTTEST_DIALOG           103
#define IDR_MAINFRAME                   128
#define IDC_VENDOR_ID                   1000
#define IDC_VENDOR_PASSWORD             1001
#define IDC_HOST_ADDRESS                1002
#define IDC_HOST_PORT                   1003
#define IDC_TRAN_TIMEOUT                1004
#define IDC_PARM_LIST                   1005
#define IDC_PROXY_ADDRESS               1006
#define IDC_PROXY_PORT                  1007
#define IDC_RESULTS_LIST                1008
#define IDC_PROXY_LOGON                 1009
#define IDC_PROXY_PASSWORD              1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
