PAYFLOW PRO COM CLIENT
----------------------------
This directory tree contains the Payflow Pro COM client and corresponding examples.  
This client is a plugin that is meant to be run in the COM environment and will
allow you to process transactions with Verisign Payment Services.

In addition to this readme file, full product documentation is
available. Download the "Payflow Pro Developer's Guide" from the
"Downloads" page of the VeriSign Manager website:
https://manager.verisign.com

REQUIREMENTS
------------
* Microsoft Windows NT 4.0/2000


CONTENTS
--------
PFProCOMSetup.exe:          	Payflow Pro client installation program
example/asp/*:             	ASP example
example/vb/*:              	Visual Basic example
example/vc/*:              	Visual Studio example
readme.txt:                	This file


INSTALLATION
------------
* Copy pfpro.dll to winnt\system32 directory
* Run PFProCOMSetup.exe to install and register the Payflow Pro client plugin


NOTE
----
COM Interface
-------------
The following are the control methods.  Please see params.txt in the root 
installation directory for the correct parameter values and the included
examples for correct usage.

    CreateContext()
    SubmitTransaction()
    DestroyContext()


NOTE
----
* You must set the SYSTEM environment variable PFPRO_CERT_PATH to point to the 
  directory that contains the file f73e89fd.0 in the certs subdirectory.  For 
  instruction see ..\bin\readme.txt



CONTACT
-------
VeriSign, Inc. 
http://www.verisign.com
See contact.txt for additional contact information
