// PNCOMClientTestDlg.h : header file
//

#if !defined(AFX_PNCOMCLIENTTESTDLG_H__D02D9886_7A6A_11D2_ABE1_00104B247C71__INCLUDED_)
#define AFX_PNCOMCLIENTTESTDLG_H__D02D9886_7A6A_11D2_ABE1_00104B247C71__INCLUDED_

#include "pfprocom.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CPNCOMClientTestDlg dialog

class CPNCOMClientTestDlg : public CDialog
{
// Construction
public:
	CPNCOMClientTestDlg(CWnd* pParent = NULL);	// standard constructor
	~CPNCOMClientTestDlg();

// Dialog Data
	//{{AFX_DATA(CPNCOMClientTestDlg)
	enum { IDD = IDD_CLIENTTEST_DIALOG };
	CListBox	m_ResultsList;
	float	m_Amount;
	CString	m_CCExpDate;
	CString	m_CCNum;
	CString	m_HostAddress;
	long	m_TranTimeout;
	long 	m_HostPort;
	CString m_ParmList;
	CString	m_ProxyAddress;
	CString	m_ProxyLogon;
	CString	m_ProxyPassword;
	long 	m_ProxyPort;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPNCOMClientTestDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	IPFProCOM *pnControl;
	void PrintResponse(CString &resp);


	// Generated message map functions
	//{{AFX_MSG(CPNCOMClientTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nParmLen;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PNCOMCLIENTTESTDLG_H__D02D9886_7A6A_11D2_ABE1_00104B247C71__INCLUDED_)
