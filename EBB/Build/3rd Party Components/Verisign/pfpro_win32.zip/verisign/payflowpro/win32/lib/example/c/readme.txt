PAYFLOW PRO TRANSACTION CLIENT V3.00 LIB EXAMPLE
------------------------------------------------
This directory contains the example for the Payflow Pro client LIB library.


REQUIREMENTS
------------
Microsoft Visual Studio 6


CONTENTS
--------
pfpro.c:        Main source file
pfpro.h:        Header file
readme.txt:     This file
pfpro.dsp:      Visual Studio 6 project file


HOW TO USE
----------
* Open pfpro.dsp in Visual Studio 6.
* Open Tools->Options and go to the Directories tab.
* In the "Show Directories for" combobox, choose Library files.
* Add the \verisign\payflowpro\win32\lib path
* Build the project
* Run the executable using the parameters specified in the param.txt file
  located in the root directory of the installation.
* You should receive a response similar to this:

RESULT=0&PNREF=VXYZ00912465&ERRCODE=00&AUTHCODE=09TEST&AVSADDR=Y&AVSZIP=N&


CONTACT
-------
Verisign, Inc.
http://www.verisign.com
See contact.txt for additional contact information
